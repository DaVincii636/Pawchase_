using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Pawchase.Models;

namespace Pawchase.Controllers
{
    // ════════════════════════════ ACCOUNT ════════════════════════════
    public class AccountController : Controller
    {
        private bool IsLoggedIn => Session["UserId"] != null;

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Login(string email, string password, string returnUrl)
        {
            try {
                if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password)) {
                    ViewBag.Error = "Email and password are required.";
                    return View();
                }
                var user = MockData.Users.FirstOrDefault(u => u.Email.ToLower() == email.ToLower().Trim());
                if (user != null && DbHelper.VerifyPassword(password, user.Password)) {
                    Session["UserId"] = user.Id; Session["UserName"] = user.FullName; Session["UserEmail"] = user.Email;
                    if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)) return Redirect(returnUrl);
                    return RedirectToAction("Index", "Home");
                }
                ViewBag.Error = "Invalid email or password.";
                return View();
            } catch (Exception ex) { System.Diagnostics.Debug.WriteLine("Login Error: " + ex.Message); return View(); }
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Register(string fullName, string email, string password, string confirmPassword)
        {
            try {
                if (string.IsNullOrWhiteSpace(fullName) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password)) {
                    ViewBag.Error = "All fields are required."; return View();
                }
                if (password != confirmPassword) { ViewBag.Error = "Passwords do not match."; return View(); }
                if (MockData.Users.Any(u => u.Email.ToLower() == email.ToLower().Trim())) {
                    ViewBag.Error = "Email already registered."; return View();
                }
                var user = new User { FullName = fullName.Trim(), Email = email.Trim().ToLower(), Password = password };
                user.Id = DbHelper.AddUser(user);
                MockData.RefreshUsers();
                Session["UserId"] = user.Id; Session["UserName"] = user.FullName; Session["UserEmail"] = user.Email;
                return RedirectToAction("Index", "Home");
            } catch (Exception ex) { System.Diagnostics.Debug.WriteLine("Register Error: " + ex.Message); return View(); }
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult SaveProfile(string fullName, string email, string phone, string gcashNumber, string currentPassword, string newPassword, string confirmPassword)
        {
            try {
                if (!IsLoggedIn) return RedirectToAction("Login");
                var userId = int.Parse(Session["UserId"].ToString());
                var user = MockData.Users.FirstOrDefault(u => u.Id == userId);
                if (user == null) return RedirectToAction("Login");

                if (!string.IsNullOrWhiteSpace(newPassword)) {
                    if (!DbHelper.VerifyPassword(currentPassword, user.Password)) {
                        TempData["ProfileError"] = "Current password incorrect."; return RedirectToAction("Orders", new { tab = "Profile" });
                    }
                    if (newPassword != confirmPassword) {
                        TempData["ProfileError"] = "New passwords mismatch."; return RedirectToAction("Orders", new { tab = "Profile" });
                    }
                    user.Password = DbHelper.HashPassword(newPassword);
                }
                user.FullName = fullName.Trim(); user.Email = email.Trim().ToLower(); user.Phone = phone?.Trim(); user.GCashNumber = gcashNumber?.Trim();
                DbHelper.UpdateUser(user); MockData.RefreshUsers();
                Session["UserName"] = user.FullName; Session["UserEmail"] = user.Email;
                TempData["ProfileSuccess"] = "Profile updated."; return RedirectToAction("Orders", new { tab = "Profile" });
            } catch (Exception ex) { System.Diagnostics.Debug.WriteLine("SaveProfile Error: " + ex.Message); return RedirectToAction("Orders", new { tab = "Profile" }); }
        }
    }

    // ════════════════════════════ CART & CHECKOUT ════════════════════════════
    public class CartController : Controller
    {
        private List<CartItem> Cart => Session["Cart"] as List<CartItem> ?? new List<CartItem>();

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult PlaceOrder(string address, string phone, string orderNotes)
        {
            try {
                if (Cart.Count == 0) return RedirectToAction("Index", "Home");
                var order = new Order {
                    ReferenceNumber = "PWC-" + Guid.NewGuid().ToString().Substring(0, 8).ToUpper(), // FIXED: Truly unique
                    CustomerName = Session["UserName"]?.ToString() ?? "Guest",
                    Email = Session["UserEmail"]?.ToString() ?? "guest@example.com",
                    Address = address, Phone = phone, OrderNotes = orderNotes,
                    Total = Cart.Sum(i => i.Subtotal), OrderDate = DateTime.Now, Status = "To Ship",
                    Snapshots = Cart.Select(i => new OrderItemSnapshot {
                        ProductId = i.Product.Id, ProductName = i.Product.Name, ProductImageUrl = i.Product.ImageUrl, Category = i.Product.Category, BreedSize = i.Product.BreedSize, UnitPrice = i.Product.Price, Quantity = i.Quantity, VariantLabel = i.SelectedVariant?.Label, VariantImageUrl = i.SelectedVariant?.ImageUrl
                    }).ToList()
                };
                int orderId = DbHelper.AddOrder(order);
                foreach (var item in Cart) {
                    var p = MockData.Products.FirstOrDefault(x => x.Id == item.Product.Id);
                    if (p != null) {
                        if (item.SelectedVariant != null) {
                            var pv = p.Variants.FirstOrDefault(v => v.Label == item.SelectedVariant.Label);
                            if (pv != null) { pv.Stock = Math.Max(0, pv.Stock - item.Quantity); DbHelper.UpdateVariantStock(p.Id, pv.Label, pv.Stock); }
                        }
                        p.Stock = Math.Max(0, p.Stock - item.Quantity); DbHelper.UpdateProductStock(p.Id, p.Stock);
                    }
                }
                Session["Cart"] = null; MockData.RefreshOrders(); MockData.RefreshProducts();
                return RedirectToAction("OrderSuccess", new { id = orderId });
            } catch (Exception ex) { System.Diagnostics.Debug.WriteLine("PlaceOrder Error: " + ex.Message); return RedirectToAction("Index", "Home"); }
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult MarkOrderReceived(int id)
        {
            try {
                DbHelper.MarkOrderReceived(id); MockData.RefreshOrders();
                return RedirectToAction("Orders", "Account");
            } catch { return RedirectToAction("Orders", "Account"); }
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult RequestRefund(int orderId, string reason, string gcash, string evidenceUrl)
        {
            try {
                DbHelper.RequestRefund(orderId, reason, gcash, evidenceUrl); MockData.RefreshOrders();
                return RedirectToAction("Orders", "Account");
            } catch { return RedirectToAction("Orders", "Account"); }
        }
    }

    // ════════════════════════════ ADMIN ════════════════════════════
    public class AdminController : Controller
    {
        private bool IsAdmin => Session["UserEmail"]?.ToString() == MockData.AdminEmail;

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult UpdateOrderStatus(int orderId, string status)
        {
            try {
                if (!IsAdmin) return RedirectToAction("Login", "Account");
                DbHelper.UpdateOrderStatus(orderId, status); MockData.RefreshOrders();
                return RedirectToAction("Orders");
            } catch { return RedirectToAction("Orders"); }
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult DenyRefund(int orderId, string reason)
        {
            try {
                if (!IsAdmin) return RedirectToAction("Login", "Account");
                DbHelper.DenyRefund(orderId, reason); MockData.RefreshOrders();
                return RedirectToAction("Orders");
            } catch { return RedirectToAction("Orders"); }
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult PostSellerReply(int reviewId, string replyText)
        {
            try {
                if (!IsAdmin) return RedirectToAction("Login", "Account");
                DbHelper.UpdateSellerReply(reviewId, replyText); MockData.RefreshReviews();
                return RedirectToAction("Reviews");
            } catch { return RedirectToAction("Reviews"); }
        }
    }
}
